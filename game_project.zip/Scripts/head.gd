extends Node3D

@export var SENSITIVITY: float = 0.005
@export var TOUCH_SPEED_MULTIPLIER: float = 350.0 # Calibrated for frame-rate delta scaling

func _ready() -> void:
	# Captures mouse frame for Windows/Desktop platforms
	if OS.get_name() in ["Windows", "macOS", "Linux"]:
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _process(delta: float) -> void:
	_handle_ui_joystick_look(delta)

func _input(event: InputEvent) -> void:
	# Windows Mouse Control
	if event is InputEventMouseMotion:
		get_parent().rotate_y(-event.relative.x * SENSITIVITY)
		rotate_x(-event.relative.y * SENSITIVITY)
		rotation.x = clamp(rotation.x, deg_to_rad(-90), deg_to_rad(90))

func _handle_ui_joystick_look(delta: float) -> void:
	var look_vec = Vector2.ZERO
	
	# Uses standard UI mappings to bypass custom Input Map setup errors
	look_vec.x = Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left")
	look_vec.y = Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
	
	if look_vec.length() > 0.0:
		var rot_y = -look_vec.x * SENSITIVITY * TOUCH_SPEED_MULTIPLIER * delta
		var rot_x = -look_vec.y * SENSITIVITY * TOUCH_SPEED_MULTIPLIER * delta
		
		get_parent().rotate_y(rot_y)
		rotate_x(rot_x)
		rotation.x = clamp(rotation.x, deg_to_rad(-90), deg_to_rad(90))
