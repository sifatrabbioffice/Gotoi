extends Control

@export var max_range: float = 85.0   # Analog bounds smoothly condensed
@export var deadzone: float = 0.15

# High-End Minimalist Translucent Palette
const COLOR_PAD_DARK   = Color(0.02, 0.03, 0.05, 0.18) # Elegant faint dark tint
const COLOR_GLOW_BLUE  = Color(0.0, 0.65, 1.0, 0.38)   # Clean premium neon touch response
const COLOR_SYM_WHITE  = Color(1.0, 1.0, 1.0, 0.65)   # Sleek vector interior markings
const COLOR_BORDER     = Color(1.0, 1.0, 1.0, 0.22)   # Ultra-thin clean profile outline

var l_track_id: int = -1
var r_track_id: int = -1

var l_base_center: Vector2
var r_base_center: Vector2
var l_stick_pos: Vector2
var r_stick_pos: Vector2

var button_rects: Dictionary = {}
var active_buttons: Dictionary = {}

func _ready() -> void:
	anchor_right = 1.0
	anchor_bottom = 1.0
	grow_horizontal = 2
	grow_vertical = 2
	mouse_filter = MOUSE_FILTER_PASS
	
	var canvas = CanvasLayer.new()
	canvas.layer = 100
	get_parent().call_deferred("add_child", canvas)
	reparent(canvas)
	
	await get_tree().process_frame
	_calculate_layout()

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		_calculate_layout()

func _calculate_layout() -> void:
	# --- OPTIMIZED SCREEN SPACING ARCHITECTURE ---
	l_base_center = Vector2(170, size.y - 160)
	l_stick_pos = l_base_center
	var dpad_center = Vector2(240, size.y - 340)
	
	r_base_center = Vector2(size.x - 310, size.y - 160)
	r_stick_pos = r_base_center
	var face_center = Vector2(size.x - 170, size.y - 280)
	
	button_rects = {
		# Upper Control Elements (Index Action Target Fields)
		"aim":           Rect2(Vector2(140, 120), Vector2(110, 85)),                                  # L2 (Sleek Dimension)
		"grenade":       Rect2(Vector2(50, 210), Vector2(95, 50)),                                    # L1
		"ps_share":      Rect2(Vector2(370, 200), Vector2(46, 46)),                                  # View Ring
		"l3_click":      Rect2(l_base_center + Vector2(40, 120) - Vector2(22, 22), Vector2(44, 44)),  # L3 Stick Node
		
		# Proportional Unified Cross D-Pad
		"dpad_up":       Rect2(dpad_center + Vector2(0, -42) - Vector2(21, 21), Vector2(42, 42)),
		"dpad_down":     Rect2(dpad_center + Vector2(0, 42) - Vector2(21, 21), Vector2(42, 42)),
		"dpad_left":     Rect2(dpad_center + Vector2(-42, 0) - Vector2(21, 21), Vector2(42, 42)),
		"dpad_right":    Rect2(dpad_center + Vector2(42, 0) - Vector2(21, 21), Vector2(42, 42)),
		
		# Upper Right Core Elements
		"fire":          Rect2(Vector2(size.x - 250, 120), Vector2(110, 85)),                        # R2 (Sleek Dimension)
		"melee":         Rect2(Vector2(size.x - 145, 210), Vector2(95, 50)),                         # R1
		"ps_options":    Rect2(Vector2(size.x - 416, 200), Vector2(46, 46)),                          # Option Ring
		"r3_click":      Rect2(r_base_center + Vector2(40, 120) - Vector2(22, 22), Vector2(44, 44)),  # R3 Stick Node
		
		# Refined Geometric Action Diamond
		"jump":          Rect2(face_center + Vector2(0, 54) - Vector2(26, 26), Vector2(52, 52)),      # Cross
		"crouch":        Rect2(face_center + Vector2(54, 0) - Vector2(26, 26), Vector2(52, 52)),      # Circle
		"weapon_swap":   Rect2(face_center + Vector2(0, -54) - Vector2(26, 26), Vector2(52, 52)),     # Triangle
		"interact":      Rect2(face_center + Vector2(-54, 0) - Vector2(26, 26), Vector2(52, 52)),     # Square
	}
	queue_redraw()

func _draw() -> void:
	# 1. SLIM LINE THUMBSTICK ANCHORS
	draw_circle(l_base_center, 78.0, COLOR_PAD_DARK)
	draw_circle(l_base_center, 78.0, COLOR_BORDER, false, 1.5)
	_draw_label_inside(l_stick_pos, "L")
	
	draw_circle(r_base_center, 78.0, COLOR_PAD_DARK)
	draw_circle(r_base_center, 78.0, COLOR_BORDER, false, 1.5)
	_draw_label_inside(r_stick_pos, "R")
	
	# 2. SEAMLESS RE4 CROSS D-PAD PROFILE
	var d_up = button_rects["dpad_up"]
	var d_down = button_rects["dpad_down"]
	var d_left = button_rects["dpad_left"]
	var d_right = button_rects["dpad_right"]
	
	var dpad_hull = PackedVector2Array([
		Vector2(d_left.position.x, d_up.position.y + d_up.size.y),
		Vector2(d_up.position.x, d_up.position.y + d_up.size.y),
		Vector2(d_up.position.x, d_up.position.y),
		Vector2(d_up.position.x + d_up.size.x, d_up.position.y),
		Vector2(d_up.position.x + d_up.size.x, d_up.position.y + d_up.size.y),
		Vector2(d_right.position.x + d_right.size.x, d_right.position.y),
		Vector2(d_right.position.x + d_right.size.x, d_right.position.y + d_right.size.y),
		Vector2(d_down.position.x + d_down.size.x, d_down.position.y),
		Vector2(d_down.position.x + d_down.size.x, d_down.position.y + d_down.size.y),
		Vector2(d_down.position.x, d_down.position.y + d_down.size.y),
		Vector2(d_down.position.x, d_down.position.y),
		Vector2(d_left.position.x, d_left.position.y + d_left.size.y)
	])
	draw_colored_polygon(dpad_hull, COLOR_PAD_DARK)
	draw_polyline(dpad_hull, COLOR_BORDER, 1.5, true)

	# 3. INTERACTIVE CONTROL ELEMENT COMPILATIONA
	for action in button_rects:
		var rect: Rect2 = button_rects[action]
		var is_pressed = active_buttons.get(action, false)
		
		var fill = COLOR_GLOW_BLUE if is_pressed else COLOR_PAD_DARK
		var border = Color.WHITE if is_pressed else COLOR_BORDER
		
		if action.begins_with("dpad_"):
			if is_pressed:
				draw_rect(rect, COLOR_GLOW_BLUE, true)
			_draw_dpad_arrows(rect, action)
		elif action in ["aim", "fire"]:
			draw_style_box(_get_rounded_box(fill, border, 16), rect)
			_draw_string_label(rect, action.to_upper())
		elif action in ["grenade", "melee"]:
			draw_style_box(_get_rounded_box(fill, border, 8), rect)
			_draw_string_label(rect, "L1" if action == "grenade" else "R1")
		elif action in ["ps_share", "ps_options", "l3_click", "r3_click"]:
			var rad = rect.size.x / 2.0
			var c = rect.position + Vector2(rad, rad)
			draw_circle(c, rad, fill)
			draw_circle(c, rad, border, false, 1.5)
			if action == "ps_share":
				_draw_menu_lines(c, false)
			elif action == "ps_options":
				_draw_menu_lines(c, true)
			else:
				_draw_label_inside(c, "L3" if action == "l3_click" else "R3")
		else: # Geometric Action Cluster Buttons
			var btn_c = rect.position + (rect.size / 2.0)
			var r = rect.size.x / 2.0
			draw_circle(btn_c, r, fill)
			draw_circle(btn_c, r, border, false, 1.5)
			draw_circle(btn_c, r - 3.5, COLOR_BORDER, false, 1.0) # Delicate Internal Styling Ring
			_draw_ps5_symbols(btn_c, action)

func _get_rounded_box(fill: Color, border: Color, radius: int) -> StyleBoxFlat:
	var sb = StyleBoxFlat.new()
	sb.bg_color = fill
	sb.border_color = border
	sb.set_border_width_all(1.5)
	sb.set_corner_radius_all(radius)
	return sb

func _draw_ps5_symbols(center: Vector2, action: String) -> void:
	match action:
		"jump":
			draw_line(center + Vector2(-7, -7), center + Vector2(7, 7), COLOR_SYM_WHITE, 2.5, true)
			draw_line(center + Vector2(-7, 7), center + Vector2(7, -7), COLOR_SYM_WHITE, 2.5, true)
		"crouch":
			draw_arc(center, 9.0, 0, TAU, 32, COLOR_SYM_WHITE, 2.5, true)
		"weapon_swap":
			var p1 = center + Vector2(0, -10)
			var p2 = center + Vector2(-9, 8)
			var p3 = center + Vector2(9, 8)
			draw_line(p1, p2, COLOR_SYM_WHITE, 2.5, true)
			draw_line(p2, p3, COLOR_SYM_WHITE, 2.5, true)
			draw_line(p3, p1, COLOR_SYM_WHITE, 2.5, true)
		"interact":
			var sq_rect = Rect2(center - Vector2(7, 7), Vector2(14, 14))
			draw_rect(sq_rect, COLOR_SYM_WHITE, false, 2.5)

func _draw_dpad_arrows(rect: Rect2, action: String) -> void:
	var c = rect.position + (rect.size / 2.0)
	match action:
		"dpad_up":
			draw_line(c + Vector2(0, -7), c + Vector2(-7, 1), COLOR_SYM_WHITE, 2.5, true)
			draw_line(c + Vector2(0, -7), c + Vector2(7, 1), COLOR_SYM_WHITE, 2.5, true)
		"dpad_down":
			draw_line(c + Vector2(0, 7), c + Vector2(-7, -1), COLOR_SYM_WHITE, 2.5, true)
			draw_line(c + Vector2(0, 7), c + Vector2(7, -1), COLOR_SYM_WHITE, 2.5, true)
		"dpad_left":
			draw_line(c + Vector2(-7, 0), c + Vector2(1, -7), COLOR_SYM_WHITE, 2.5, true)
			draw_line(c + Vector2(-7, 0), c + Vector2(1, 7), COLOR_SYM_WHITE, 2.5, true)
		"dpad_right":
			draw_line(c + Vector2(7, 0), c + Vector2(-1, -7), COLOR_SYM_WHITE, 2.5, true)
			draw_line(c + Vector2(7, 0), c + Vector2(-1, 7), COLOR_SYM_WHITE, 2.5, true)

func _draw_menu_lines(center: Vector2, is_options: bool) -> void:
	if is_options:
		draw_line(center + Vector2(-7, -5), center + Vector2(7, -5), COLOR_SYM_WHITE, 2.0)
		draw_line(center + Vector2(-7, 0), center + Vector2(7, 0), COLOR_SYM_WHITE, 2.0)
		draw_line(center + Vector2(-7, 5), center + Vector2(7, 5), COLOR_SYM_WHITE, 2.0)
	else:
		var sq = Rect2(center - Vector2(6, 6), Vector2(12, 12))
		draw_rect(sq, COLOR_SYM_WHITE, false, 2.0)
		draw_line(center + Vector2(0, -1), center + Vector2(0, 3), COLOR_SYM_WHITE, 2.0)
		draw_line(center + Vector2(0, 3), center + Vector2(-3, 0), COLOR_SYM_WHITE, 2.0)
		draw_line(center + Vector2(0, 3), center + Vector2(3, 0), COLOR_SYM_WHITE, 2.0)

func _draw_label_inside(center: Vector2, txt: String) -> void:
	draw_arc(center, 13.0, 0, TAU, 32, COLOR_BORDER, 1.5, true)
	if txt == "L" or txt == "R":
		draw_line(center + Vector2(-4, -4), center + Vector2(-4, 4), COLOR_SYM_WHITE, 2.5)
		draw_line(center + Vector2(-4, 4), center + Vector2(2, 4), COLOR_SYM_WHITE, 2.5)
		if txt == "R":
			draw_line(center + Vector2(-4, -4), center + Vector2(2, -4), COLOR_SYM_WHITE, 2.5)
			draw_line(center + Vector2(2, -4), center + Vector2(2, 0), COLOR_SYM_WHITE, 2.5)
			draw_line(center + Vector2(-4, 0), center + Vector2(2, 0), COLOR_SYM_WHITE, 2.5)
			draw_line(center + Vector2(-1, 0), center + Vector2(3, 4), COLOR_SYM_WHITE, 2.5)

func _draw_string_label(rect: Rect2, label: String) -> void:
	var center = rect.position + (rect.size / 2.0)
	if label == "AIM" or label == "L2":
		draw_line(center + Vector2(-9, -6), center + Vector2(-9, 6), COLOR_SYM_WHITE, 3.0)
		draw_line(center + Vector2(-9, -6), center + Vector2(3, -6), COLOR_SYM_WHITE, 3.0)
		draw_line(center + Vector2(3, -6), center + Vector2(3, 6), COLOR_SYM_WHITE, 3.0)
		draw_line(center + Vector2(-9, 0), center + Vector2(3, 0), COLOR_SYM_WHITE, 3.0)
	elif label == "FIRE" or label == "R2":
		draw_line(center + Vector2(-9, -6), center + Vector2(-9, 6), COLOR_SYM_WHITE, 3.0)
		draw_line(center + Vector2(-9, -6), center + Vector2(3, -6), COLOR_SYM_WHITE, 3.0)
		draw_line(center + Vector2(3, -6), center + Vector2(3, 0), COLOR_SYM_WHITE, 3.0)
		draw_line(center + Vector2(-9, 0), center + Vector2(3, 0), COLOR_SYM_WHITE, 3.0)
		draw_line(center + Vector2(-1, 0), center + Vector2(5, 6), COLOR_SYM_WHITE, 3.0)
	else:
		draw_line(center + Vector2(-8, 0), center + Vector2(8, 0), COLOR_SYM_WHITE, 2.5)

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_process_touch_down(event.position, event.index)
		else:
			_process_touch_up(event.index)
	elif event is InputEventScreenDrag:
		_process_drag(event.position, event.index)

func _process_touch_down(pos: Vector2, index: int) -> void:
	for action in button_rects:
		if button_rects[action].has_point(pos):
			active_buttons[action] = index
			Input.action_press(action, 1.0)
			queue_redraw()
			return
			
	if pos.distance_to(l_base_center) < 100.0 and l_track_id == -1:
		l_track_id = index
		_update_stick(pos, true)
	elif pos.distance_to(r_base_center) < 100.0 and r_track_id == -1:
		r_track_id = index
		_update_stick(pos, false)

func _process_drag(pos: Vector2, index: int) -> void:
	if index == l_track_id:
		_update_stick(pos, true)
	elif index == r_track_id:
		_update_stick(pos, false)
	else:
		for action in button_rects:
			if button_rects[action].has_point(pos) and not active_buttons.has(action):
				active_buttons[action] = index
				Input.action_press(action, 1.0)
				queue_redraw()

func _process_touch_up(index: int) -> void:
	if index == l_track_id:
		l_track_id = -1
		l_stick_pos = l_base_center
		_clear_actions(["move_left", "move_right", "move_forward", "move_back"])
	elif index == r_track_id:
		r_track_id = -1
		r_stick_pos = r_base_center
		_clear_actions(["look_left", "look_right", "look_up", "look_down"])
		
	for action in active_buttons.keys():
		if active_buttons[action] == index:
			active_buttons.erase(action)
			Input.action_release(action)
	queue_redraw()

func _update_stick(touch_pos: Vector2, is_left: bool) -> void:
	var base = l_base_center if is_left else r_base_center
	var offset = touch_pos - base
	
	if offset.length() > max_range:
		offset = offset.normalized() * max_range
		
	if is_left:
		l_stick_pos = base + offset
	else:
		r_stick_pos = base + offset
		
	var out = offset / max_range
	if out.length() < deadzone: 
		out = Vector2.ZERO
		
	var actions = ["move_left", "move_right", "move_forward", "move_back"] if is_left else ["look_left", "look_right", "look_up", "look_down"]
	_inject_axis(out, actions)
	queue_redraw()

func _inject_axis(vec: Vector2, acts: Array) -> void:
	if vec.x < 0:
		Input.action_press(acts[0], abs(vec.x))
		Input.action_release(acts[1])
	elif vec.x > 0:
		Input.action_press(acts[1], vec.x)
		Input.action_release(acts[0])
	else:
		Input.action_release(acts[0])
		Input.action_release(acts[1])

	if vec.y < 0:
		Input.action_press(acts[2], abs(vec.y))
		Input.action_release(acts[3])
	elif vec.y > 0:
		Input.action_press(acts[3], vec.y)
		Input.action_release(acts[2])
	else:
		Input.action_release(acts[2])
		Input.action_release(acts[3])

func _clear_actions(acts: Array) -> void:
	for a in acts: 
		Input.action_release(a)
